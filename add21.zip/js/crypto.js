 /*!
 * Crypto-JS v2.0.0
 * http://code.google.com/p/crypto-js/
 * Copyright (c) 2009, Jeff Mott. All rights reserved.
 * http://code.google.com/p/crypto-js/wiki/License
 * +
 * A JavaScript implementation of the RIPEMD-160 Algorithm
 * Version 2.2 Copyright Jeremy Lin, Paul Johnston 2000 - 2009.
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for details.
 * Also http://www.ocf.berkeley.edu/~jjlin/jsotp/
 * Ported to Crypto-JS by Stefan Thomas.
 */

// Global Crypto object
var Crypto = {};

(function() {
    
    var base64map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    // Crypto utilities
    var util = Crypto.util = {

        // Bit-wise rotate left
        rotl: function(n, b) {
            return (n << b) | (n >>> (32 - b));
        },

        // Bit-wise rotate right
        rotr: function(n, b) {
            return (n << (32 - b)) | (n >>> b);
        },

        // Swap big-endian to little-endian and vice versa
        endian: function(n) {

            // If number given, swap endian
            if (n.constructor == Number) {
                return util.rotl(n, 8) & 0x00FF00FF | 
                util.rotl(n, 24) & 0xFF00FF00;
            }

            // Else, assume array and swap all items
            for (var i = 0; i < n.length; i++)
                n[i] = util.endian(n[i]);
            return n;
        
        },

        // Generate an array of any length of random bytes
        randomBytes: function(n) {
            for (var bytes = []; n > 0; n--)
                bytes.push(Math.floor(Math.random() * 256));
            return bytes;
        },

        // Convert a byte array to big-endian 32-bit words
        bytesToWords: function(bytes) {
            for (var words = [], i = 0, b = 0; i < bytes.length; i++, b += 8)
                words[b >>> 5] |= bytes[i] << (24 - b % 32);
            return words;
        },

        // Convert big-endian 32-bit words to a byte array
        wordsToBytes: function(words) {
            for (var bytes = [], b = 0; b < words.length * 32; b += 8)
                bytes.push((words[b >>> 5] >>> (24 - b % 32)) & 0xFF);
            return bytes;
        },

        // Convert a byte array to a hex string
        bytesToHex: function(bytes) {
            for (var hex = [], i = 0; i < bytes.length; i++) {
                hex.push((bytes[i] >>> 4).toString(16));
                hex.push((bytes[i] & 0xF).toString(16));
            }
            return hex.join("");
        },

        // Convert a hex string to a byte array
        hexToBytes: function(hex) {
            for (var bytes = [], c = 0; c < hex.length; c += 2)
                bytes.push(parseInt(hex.substr(c, 2), 16));
            return bytes;
        },

        // Convert a byte array to a base-64 string
        bytesToBase64: function(bytes) {

            // Use browser-native function if it exists
            if (typeof btoa == "function")
                return btoa(Binary.bytesToString(bytes));
            
            for (var base64 = [], i = 0; i < bytes.length; i += 3) {
                var triplet = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2];
                for (var j = 0; j < 4; j++) {
                    if (i * 8 + j * 6 <= bytes.length * 8)
                        base64.push(base64map.charAt((triplet >>> 6 * (3 - j)) & 0x3F));
                    else
                        base64.push("=");
                }
            }
            
            return base64.join("");
        
        },

        // Convert a base-64 string to a byte array
        base64ToBytes: function(base64) {

            // Use browser-native function if it exists
            if (typeof atob == "function")
                return Binary.stringToBytes(atob(base64));

            // Remove non-base-64 characters
            base64 = base64.replace(/[^A-Z0-9+\/]/ig, "");
            
            for (var bytes = [], i = 0, imod4 = 0; i < base64.length; imod4 = ++i % 4) {
                if (imod4 == 0)
                    continue;
                bytes.push(((base64map.indexOf(base64.charAt(i - 1)) & (Math.pow(2, -2 * imod4 + 8) - 1)) << (imod4 * 2)) | 
                (base64map.indexOf(base64.charAt(i)) >>> (6 - imod4 * 2)));
            }
            
            return bytes;
        
        }
    
    };

    // Crypto mode namespace
    Crypto.mode = {};

    // Crypto character encodings
    var charenc = Crypto.charenc = {};

    // UTF-8 encoding
    var UTF8 = charenc.UTF8 = {

        // Convert a string to a byte array
        stringToBytes: function(str) {
            return Binary.stringToBytes(unescape(encodeURIComponent(str)));
        },

        // Convert a byte array to a string
        bytesToString: function(bytes) {
            return decodeURIComponent(escape(Binary.bytesToString(bytes)));
        }
    
    };

    // Binary encoding
    var Binary = charenc.Binary = {

        // Convert a string to a byte array
        stringToBytes: function(str) {
            for (var bytes = [], i = 0; i < str.length; i++)
                bytes.push(str.charCodeAt(i));
            return bytes;
        },

        // Convert a byte array to a string
        bytesToString: function(bytes) {
            for (var str = [], i = 0; i < bytes.length; i++)
                str.push(String.fromCharCode(bytes[i]));
            return str.join("");
        }
    
    };

})();

(function() {

    // Shortcuts
    var C = Crypto, 
    util = C.util, 
    charenc = C.charenc, 
    UTF8 = charenc.UTF8, 
    Binary = charenc.Binary;

    // Constants
    var K = [0x428A2F98, 0x71374491, 0xB5C0FBCF, 0xE9B5DBA5, 
        0x3956C25B, 0x59F111F1, 0x923F82A4, 0xAB1C5ED5, 
        0xD807AA98, 0x12835B01, 0x243185BE, 0x550C7DC3, 
        0x72BE5D74, 0x80DEB1FE, 0x9BDC06A7, 0xC19BF174, 
        0xE49B69C1, 0xEFBE4786, 0x0FC19DC6, 0x240CA1CC, 
        0x2DE92C6F, 0x4A7484AA, 0x5CB0A9DC, 0x76F988DA, 
        0x983E5152, 0xA831C66D, 0xB00327C8, 0xBF597FC7, 
        0xC6E00BF3, 0xD5A79147, 0x06CA6351, 0x14292967, 
        0x27B70A85, 0x2E1B2138, 0x4D2C6DFC, 0x53380D13, 
        0x650A7354, 0x766A0ABB, 0x81C2C92E, 0x92722C85, 
        0xA2BFE8A1, 0xA81A664B, 0xC24B8B70, 0xC76C51A3, 
        0xD192E819, 0xD6990624, 0xF40E3585, 0x106AA070, 
        0x19A4C116, 0x1E376C08, 0x2748774C, 0x34B0BCB5, 
        0x391C0CB3, 0x4ED8AA4A, 0x5B9CCA4F, 0x682E6FF3, 
        0x748F82EE, 0x78A5636F, 0x84C87814, 0x8CC70208, 
        0x90BEFFFA, 0xA4506CEB, 0xBEF9A3F7, 0xC67178F2];

    // Public API
    var SHA256 = C.SHA256 = function(message, options) {
        var digestbytes = util.wordsToBytes(SHA256._sha256(message));
        return options && options.asBytes ? digestbytes : 
        options && options.asString ? Binary.bytesToString(digestbytes) : 
        util.bytesToHex(digestbytes);
    };

    // The core
    SHA256._sha256 = function(message) {

        // Convert to byte array
        if (message.constructor == String)
            message = UTF8.stringToBytes(message);
        /* else, assume byte array already */
        
        var m = util.bytesToWords(message), 
        l = message.length * 8, 
        H = [0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A, 
            0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19], 
        w = [], 
        a, b, c, d, e, f, g, h, i, j, 
        t1, t2;

        // Padding
        m[l >> 5] |= 0x80 << (24 - l % 32);
        m[((l + 64 >> 9) << 4) + 15] = l;
        
        for (var i = 0; i < m.length; i += 16) {
            
            a = H[0];
            b = H[1];
            c = H[2];
            d = H[3];
            e = H[4];
            f = H[5];
            g = H[6];
            h = H[7];
            
            for (var j = 0; j < 64; j++) {
                
                if (j < 16)
                    w[j] = m[j + i];
                else {
                    
                    var gamma0x = w[j - 15], 
                    gamma1x = w[j - 2], 
                    gamma0 = ((gamma0x << 25) | (gamma0x >>> 7)) ^ 
                    ((gamma0x << 14) | (gamma0x >>> 18)) ^ 
                    (gamma0x >>> 3), 
                    gamma1 = ((gamma1x << 15) | (gamma1x >>> 17)) ^ 
                    ((gamma1x << 13) | (gamma1x >>> 19)) ^ 
                    (gamma1x >>> 10);
                    
                    w[j] = gamma0 + (w[j - 7] >>> 0) + 
                    gamma1 + (w[j - 16] >>> 0);
                
                }
                
                var ch = e & f ^ ~e & g, 
                maj = a & b ^ a & c ^ b & c, 
                sigma0 = ((a << 30) | (a >>> 2)) ^ 
                ((a << 19) | (a >>> 13)) ^ 
                ((a << 10) | (a >>> 22)), 
                sigma1 = ((e << 26) | (e >>> 6)) ^ 
                ((e << 21) | (e >>> 11)) ^ 
                ((e << 7) | (e >>> 25));
                
                
                t1 = (h >>> 0) + sigma1 + ch + (K[j]) + (w[j] >>> 0);
                t2 = sigma0 + maj;
                
                h = g;
                g = f;
                f = e;
                e = d + t1;
                d = c;
                c = b;
                b = a;
                a = t1 + t2;
            
            }
            
            H[0] += a;
            H[1] += b;
            H[2] += c;
            H[3] += d;
            H[4] += e;
            H[5] += f;
            H[6] += g;
            H[7] += h;
        
        }
        
        return H;
    
    };

    // Package private blocksize
    SHA256._blocksize = 16;

})();

(function() {
    // Shortcuts
    var C = Crypto, 
    util = C.util, 
    charenc = C.charenc, 
    UTF8 = charenc.UTF8, 
    Binary = charenc.Binary;

    // Convert a byte array to little-endian 32-bit words
    util.bytesToLWords = function(bytes) {
        
        var output = Array(bytes.length >> 2);
        for (var i = 0; i < output.length; i++)
            output[i] = 0;
        for (var i = 0; i < bytes.length * 8; i += 8)
            output[i >> 5] |= (bytes[i / 8] & 0xFF) << (i % 32);
        return output;
    };

    // Convert little-endian 32-bit words to a byte array
    util.lWordsToBytes = function(words) {
        var output = [];
        for (var i = 0; i < words.length * 32; i += 8)
            output.push((words[i >> 5] >>> (i % 32)) & 0xff);
        return output;
    };

    // Public API
    var RIPEMD160 = C.RIPEMD160 = function(message, options) {
        var digestbytes = util.lWordsToBytes(RIPEMD160._rmd160(message));
        return options && options.asBytes ? digestbytes : 
        options && options.asString ? Binary.bytesToString(digestbytes) : 
        util.bytesToHex(digestbytes);
    };

    // The core
    RIPEMD160._rmd160 = function(message) 
    {
        // Convert to byte array
        if (message.constructor == String)
            message = UTF8.stringToBytes(message);
        
        var x = util.bytesToLWords(message), 
        len = message.length * 8;

        /* append padding */
        x[len >> 5] |= 0x80 << (len % 32);
        x[(((len + 64) >>> 9) << 4) + 14] = len;
        
        var h0 = 0x67452301;
        var h1 = 0xefcdab89;
        var h2 = 0x98badcfe;
        var h3 = 0x10325476;
        var h4 = 0xc3d2e1f0;
        
        for (var i = 0; i < x.length; i += 16) {
            var T;
            var A1 = h0, B1 = h1, C1 = h2, D1 = h3, E1 = h4;
            var A2 = h0, B2 = h1, C2 = h2, D2 = h3, E2 = h4;
            for (var j = 0; j <= 79; ++j) {
                T = safe_add(A1, rmd160_f(j, B1, C1, D1));
                T = safe_add(T, x[i + rmd160_r1[j]]);
                T = safe_add(T, rmd160_K1(j));
                T = safe_add(bit_rol(T, rmd160_s1[j]), E1);
                A1 = E1;
                E1 = D1;
                D1 = bit_rol(C1, 10);
                C1 = B1;
                B1 = T;
                T = safe_add(A2, rmd160_f(79 - j, B2, C2, D2));
                T = safe_add(T, x[i + rmd160_r2[j]]);
                T = safe_add(T, rmd160_K2(j));
                T = safe_add(bit_rol(T, rmd160_s2[j]), E2);
                A2 = E2;
                E2 = D2;
                D2 = bit_rol(C2, 10);
                C2 = B2;
                B2 = T;
            }
            T = safe_add(h1, safe_add(C1, D2));
            h1 = safe_add(h2, safe_add(D1, E2));
            h2 = safe_add(h3, safe_add(E1, A2));
            h3 = safe_add(h4, safe_add(A1, B2));
            h4 = safe_add(h0, safe_add(B1, C2));
            h0 = T;
        }
        return [h0, h1, h2, h3, h4];
    }
    
    function rmd160_f(j, x, y, z) 
    {
        return (0 <= j && j <= 15) ? (x ^ y ^ z) : 
        (16 <= j && j <= 31) ? (x & y) | (~x & z) : 
        (32 <= j && j <= 47) ? (x | ~y) ^ z : 
        (48 <= j && j <= 63) ? (x & z) | (y & ~z) : 
        (64 <= j && j <= 79) ? x ^ (y | ~z) : 
        "rmd160_f: j out of range";
    }
    function rmd160_K1(j) 
    {
        return (0 <= j && j <= 15) ? 0x00000000 : 
        (16 <= j && j <= 31) ? 0x5a827999 : 
        (32 <= j && j <= 47) ? 0x6ed9eba1 : 
        (48 <= j && j <= 63) ? 0x8f1bbcdc : 
        (64 <= j && j <= 79) ? 0xa953fd4e : 
        "rmd160_K1: j out of range";
    }
    function rmd160_K2(j) 
    {
        return (0 <= j && j <= 15) ? 0x50a28be6 : 
        (16 <= j && j <= 31) ? 0x5c4dd124 : 
        (32 <= j && j <= 47) ? 0x6d703ef3 : 
        (48 <= j && j <= 63) ? 0x7a6d76e9 : 
        (64 <= j && j <= 79) ? 0x00000000 : 
        "rmd160_K2: j out of range";
    }
    var rmd160_r1 = [
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 
        7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 
        3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 
        1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 
        4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13
    ];
    var rmd160_r2 = [
        5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 
        6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 
        15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 
        8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 
        12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11
    ];
    var rmd160_s1 = [
        11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 
        7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 
        11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 
        11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 
        9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6
    ];
    var rmd160_s2 = [
        8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 
        9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 
        9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 
        15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 
        8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11
    ];

    /*
         * Add integers, wrapping at 2^32. This uses 16-bit operations internally
         * to work around bugs in some JS interpreters.
         */
    function safe_add(x, y) 
    {
        var lsw = (x & 0xFFFF) + (y & 0xFFFF);
        var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
        return (msw << 16) | (lsw & 0xFFFF);
    }

    /*
         * Bitwise rotate a 32-bit number to the left.
         */
    function bit_rol(num, cnt) 
    {
        return (num << cnt) | (num >>> (32 - cnt));
    }
})();
